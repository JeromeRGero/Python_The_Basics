import sys

def q():
    global doneYet
    doneYet += 1
    valid = {
        "yes": True,
        "y": True,
        "ye": True,
        "no": False,
        "n": False
    }

    prompt = "#######################################\nContinue? [y/n]: "
    sys.stdout.write(prompt)

    a = 0

    if doneYet == 4:
        quit()

    while a == 0:
        choice = raw_input().lower()
        if a is not None and choice == "":
            return valid["yes"]
        elif choice in valid:
            if valid[choice] == True:
                sys.stdout.write("Continuing!\n")
                return
            else:
                quit()
        else:
            sys.stdout.write("Please respond with 'yes' or 'no' ('y' or 'n') \nContinue? [y/n]: ")


def figure_out(g):
    a = 0
    while a == 0:
        if isinstance(g, int):
            if g >= 100:
                print("Thats a BIG number!\n")
                return
            else:
                print("Small... so very small.\n")
                return
        elif isinstance(g, str):
            if len(g) >= 50:
                print("Long sentance...")
                return
            else:
                print("Short and to the point! I like it.\n")
                return
        elif isinstance(g, list):
            if len(g) >= 10:
                print("That is a lot of data!")
                return
            else:
                print("A short list, but still a list!")
                return
        else:
            print ("What???\n")

figure_out([1, 2, 3])