
mySelf = {
    "name": "Jerome",
    "age": 25,
    "country": "New Jersey (Its a country, I promise)",
    "language": "Omgrofl"
}

def print_fun(obj):
    print("My name is {}. \nMy age is {}. \nI was born in the great wonderful country of {}. \nMy favorite lang is {}.".format(obj["name"], obj["age"], obj["country"], obj["language"]))

print_fun(mySelf)

# class User():
# #     name = "josh"
# #
# # print User().name