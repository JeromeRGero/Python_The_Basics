import random
import math

x = 1
lsNum = [90, 80, 70, 60, 50]
lsGrade = ['A', 'B', 'C', 'D', 'F']

while x < 11:
    r_num = int(math.floor(random.random() * 40 + 61))
    a = 0
    for i in range(0, len(lsNum)):
        if a == 0 and lsNum[i] <= r_num:
            str(r_num)
            grade = lsGrade[i]
            print("Score: {}; Your grade is {}".format(r_num, grade))
            a += 1
    x += 1



print("End of progrm. Bye!")